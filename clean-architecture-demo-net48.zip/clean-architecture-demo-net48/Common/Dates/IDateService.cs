﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CleanArchitecture.Common.Dates
{
    public interface IDateService
    {
        DateTime GetDate();
    }
}
