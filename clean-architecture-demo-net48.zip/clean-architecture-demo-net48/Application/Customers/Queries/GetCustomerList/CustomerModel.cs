﻿namespace CleanArchitecture.Application.Customers.Queries.GetCustomerList
{
    public class CustomerModel
    {
        public int Id { get; set; }

        public string Name { get; set; }
    }
}